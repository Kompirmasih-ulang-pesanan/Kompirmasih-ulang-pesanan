<?php
$id_telegram = "6603389498";
$id_botTele  = "7171747187:AAGeUWIpwtfNaFDmsOOTOKTYGbMn5n3Dq10";
?>
